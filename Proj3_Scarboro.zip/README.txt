Welcome to my Hash Table!
Name:Craig Scarboro

-----DESCRIPTION-----
The program takes in text input from a user provided text file and then proceedes to store this
text into a hash table utilizing external chaining to handle collisions. After storing the data
the program then sorts the data using selection sort and prints out every unique word in the text
with how many times it appeard.

-----TO RUN THE PROGRAM-----
Type "make" to compile the program. Then type ./Project3 in order to start it up. 

Typing "make clean" will clean up the object files generated during coimpilation.

-----USING THE PROGRAM-----
The program will ask for a text file (including the .txt extension) and proceed to hash, sort,
and print the data.